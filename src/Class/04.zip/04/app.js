import GoodsCounter from "./goodscounter";

function App(){
    return(
        <div className="App">
            <h1>hest2</h1>
            <GoodsCounter></GoodsCounter>
        </div>
    )
}

export default App;